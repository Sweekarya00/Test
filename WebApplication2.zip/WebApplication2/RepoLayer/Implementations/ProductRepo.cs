﻿using BusinessLayer.Interfaces;
using DataLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Implementations
{
    public class ProductRepo : IProductRepo
    {
        private readonly PaymentDetailDbContext _context;

        public ProductRepo(PaymentDetailDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<PaymentDetail>> GetAll()
        {
            var employees = await _context.PaymentDetails.ToListAsync();
            return employees;
        }

        public async Task<PaymentDetail> GetById(int id)
        {
            return await _context.PaymentDetails.FindAsync(id);
        }

        public async Task Add(PaymentDetail model)
        {
            await _context.PaymentDetails.AddAsync(model);
            _context.SaveChanges();
        }
        public async Task Update(PaymentDetail model)
        {
            var employee = await _context.PaymentDetails.FindAsync(model.Id);
            if (employee != null) 
            { 
                employee.Name = model.Name;
                employee.Department = model.Department;
                employee.Pay = model.Pay;
                _context.Update(employee);
                _context.SaveChanges();
            }
        }

        public async Task Delete(int id)
        {
            var employee = await _context.PaymentDetails.FindAsync(id);
            if (employee != null)
            {
                _context.PaymentDetails.Remove(employee);
                _context.SaveChanges();
            }
        }
        //public async Task<PaymentDetail> Pay(int id)
        //{
        //    var employee = await _context.PaymentDetails.FindAsync(id);
        //    if (employee != null)
        //    {
        //        employee.Status = model.Status;
                
        //        _context.Update(employee);
        //        _context.SaveChanges();
        //    }
        //}
    }
}
