﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IProductRepo
    {
        Task<IEnumerable<PaymentDetail>> GetAll();
        Task<PaymentDetail> GetById(int id);
        Task Add(PaymentDetail model);
        Task Update(PaymentDetail model);
        Task Delete(int id);
        //Task<PaymentDetail> Pay(int id);
    }
}
