﻿using BusinessLayer.Interfaces;
using DataLayer;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class PaymentController : Controller
    {
        private readonly IProductRepo _productRepo;

        public PaymentController(IProductRepo productRepo)
        {
            _productRepo = productRepo;
        }

        public async Task<IActionResult> Index()
        {
            var employees =await _productRepo.GetAll();
            return View(employees);
        }

        [HttpGet]
        public async Task<IActionResult> CreateorEdit(int id=0)
        {
            if (id == 0)
            {
                return View(new PaymentDetail());
            }
            else
            {
                PaymentDetail detail = await _productRepo.GetById(id);
                if (detail != null) 
                {
                    return View(detail);
                }
                TempData["errorMessage"] = $"Employee not found with this ID : {id}";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateorEdit(PaymentDetail model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (model.Id == 0) 
                    {
                        await _productRepo.Add(model);
                        TempData["successMessage"] = "Employee added successfully";
                        return RedirectToAction(nameof(Index));
                    }else
                    {
                        await _productRepo.Update(model);
                        TempData["successMessage"] = "Employee updated successfully";
                    }
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["errorMessage"] = "Model state is invalid";
                    return View();
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            PaymentDetail detail = await _productRepo.GetById(id);
            if (detail != null)
            {
                return View(detail);
            }
            TempData["errorMessage"] = $"Employee not found with this ID : {id}";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _productRepo.Delete(id);
            TempData["successMessage"] = "Employee deleted successfully";
            return RedirectToAction(nameof(Index));
        }
        //[HttpGet]
        //public async Task<IActionResult> Pay(PaymentDetail model)
        //{
        //    PaymentDetail detail = await _productRepo.GetById(id);
        //    if (detail != null)
        //    {
        //        return View(detail);
        //    }
        //    TempData["errorMessage"] = $"Employee not found with this ID : {id}";
        //    return RedirectToAction(nameof(Index));
        //}
        //[HttpPost, ActionName("Pay")]
        //public async Task<IActionResult> PayConfirmed(PaymentDetail model)
        //{
        //    await _productRepo.Delete(id);
        //    TempData["successMessage"] = "Employee deleted successfully";
        //    return RedirectToAction(nameof(Index));
        //}
    }
}
